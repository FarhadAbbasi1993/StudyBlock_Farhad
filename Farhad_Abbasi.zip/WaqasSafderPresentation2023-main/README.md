# WaqasSafderPresentation2023
Internet Technalogies client side Study Block Project
